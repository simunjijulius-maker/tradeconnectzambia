import OpenAI from "openai";

const SUPABASE_URL = "https://anicgbjdbahffxckdyto.supabase.co";
// This is the public Supabase publishable key already used by the website. It is not a service-role secret.
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_7yIWnCRMb4jRG8DrZhRwSw_kC1MFxg3";

const text = (value, max = 4000) => typeof value === "string" ? value.trim().slice(0, max) : "";

export default async (request) => {
  if (request.method !== "POST") {
    return Response.json({ error: "Method not allowed." }, { status: 405 });
  }

  const authorization = request.headers.get("authorization") || "";
  if (!authorization.startsWith("Bearer ")) {
    return Response.json({ error: "Please sign in to use Julius AI Tec." }, { status: 401 });
  }

  // Verify the user's Supabase session server-side; never trust a user ID from the browser.
  const authResponse = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SUPABASE_PUBLISHABLE_KEY, Authorization: authorization },
  });
  if (!authResponse.ok) {
    return Response.json({ error: "Your session is invalid or expired. Please sign in again." }, { status: 401 });
  }

  let body;
  try { body = await request.json(); }
  catch { return Response.json({ error: "Please submit valid document details." }, { status: 400 }); }

  const documentType = body?.documentType === "application_letter" ? "application_letter" : body?.documentType === "cv" ? "cv" : null;
  const fullName = text(body?.fullName, 100);
  if (!documentType || !fullName) {
    return Response.json({ error: "Choose a document type and enter your full name." }, { status: 400 });
  }

  const details = {
    fullName,
    phone: text(body.phone, 60),
    email: text(body.email, 120),
    location: text(body.location, 120),
    education: text(body.education, 2500),
    skills: text(body.skills, 2500),
    experience: text(body.experience, 3000),
    target: text(body.target, 300),
    extra: text(body.extra, 1500),
  };
  const supplied = Object.entries(details).filter(([, value]) => value).map(([key, value]) => `${key}: ${value}`).join("\n");

  if (!Netlify.env.get("OPENAI_BASE_URL") || !Netlify.env.get("OPENAI_API_KEY")) {
    return Response.json({ error: "Netlify AI Gateway is not active for this deployment yet. The site needs a production deploy on a credit-based Netlify plan." }, { status: 503 });
  }

  try {
    const client = new OpenAI();
    const kind = documentType === "cv" ? "a professional CV / resume" : "a formal job application letter";
    const completion = await client.chat.completions.create({
      model: "gpt-5-nano",
      max_completion_tokens: 1800,
      messages: [
        { role: "system", content: "You are Julius AI Tec, a careful career-document assistant for TradeConnect Zambia. Write clear, professional Zambian/British English. Use only facts explicitly supplied by the user. Never invent qualifications, schools, certificates, employers, job titles, dates, achievements, references, addresses or contact details. If important information is missing, use a short bracketed placeholder such as [Add qualification and year]. Do not claim the user has experience they did not provide. Return only the finished editable document, with sensible headings and spacing. Do not include markdown code fences or commentary." },
        { role: "user", content: `Create ${kind} using the details below. Improve clarity and presentation without changing the facts. For a CV, organise the information into an appropriate profile, skills, education, experience/projects and references section (use placeholders where missing). For an application letter, address the stated role/organisation, explain the user's genuine relevant skills and background, and keep it to one page where practical.\n\nUser-provided details:\n${supplied}\n\nDocument type: ${documentType}` },
      ],
    });
    const document = completion.choices?.[0]?.message?.content?.trim();
    if (!document) return Response.json({ error: "The AI did not return a document. Please try again." }, { status: 502 });
    return Response.json({ document, model: completion.model || "gpt-5-nano" });
  } catch (error) {
    console.error("Julius AI Tec generation failed:", error?.message || "unknown error");
    return Response.json({ error: "Julius AI Tec is temporarily unavailable. Please try again shortly." }, { status: 502 });
  }
};

export const config = {
  path: "/.netlify/functions/julius-ai",
  method: "POST",
  rateLimit: { action: "rate_limit", aggregateBy: "ip", windowSize: 60, windowLimit: 4 },
};
